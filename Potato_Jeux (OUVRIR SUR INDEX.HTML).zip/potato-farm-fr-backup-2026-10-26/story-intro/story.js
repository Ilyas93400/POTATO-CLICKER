﻿(() => {
  const $ = (selector) => document.querySelector(selector);
  const world = $('#world');
  const fade = $('#fade-curtain');
  const envelope = $('#envelope');
  const preview = $('#paper-preview');
  const paper = $('#news-paper');
  const phone = $('#phone-wrap');
  const hint = $('#hint');
  const storageGet = (key, fallback = null) => { try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; } };
  const storageSet = (key, value) => { try { localStorage.setItem(key, value); } catch {} };
  const params = new URLSearchParams(location.search);
  const farmName = params.get('farmName') || storageGet('fermeAuxPatates.farmName') || 'Ma ferme';
  storageSet('fermeAuxPatates.farmName', farmName);

  requestAnimationFrame(() => {
    fade.classList.remove('start-black');
    fade.classList.add('reveal');
    setTimeout(() => fade.classList.remove('reveal'), 780);
  });

  envelope.addEventListener('click', () => {
    if (envelope.classList.contains('open')) return;
    envelope.classList.add('open');
    hint.textContent = 'Une lettre officielle… Ouvrez-la !';
    setTimeout(() => {
      envelope.classList.add('hidden');
      preview.classList.remove('hidden');
      hint.textContent = 'Touchez la feuille pour la lire';
    }, 720);
  });

  preview.addEventListener('click', () => {
    world.classList.add('paused');
    preview.classList.add('hidden');
    paper.classList.remove('hidden');
    hint.classList.add('hidden');
  });

  $('#news-continue').addEventListener('click', () => {
    fade.classList.remove('on');
    void fade.offsetWidth;
    fade.classList.add('on');
    setTimeout(() => {
      paper.classList.add('hidden');
      hint.classList.remove('hidden');
      hint.textContent = 'Votre compte en banque…';
      phone.classList.remove('hidden');
    }, 410);
  });

  $('#start-farming').addEventListener('click', () => {
    fade.classList.remove('on');
    void fade.offsetWidth;
    fade.classList.add('on');
    setTimeout(() => {
      location.href = `../game.html?start=story&farmName=${encodeURIComponent(farmName)}`;
    }, 430);
  });
})();
