﻿// Add your Supabase project URL and publishable key here.
// Never put a secret or service_role key in this browser file.
window.FERME_SUPABASE = {
  url: '',
  anonKey: ''
};
