create table if not exists public.leaderboard (
  id bigint generated always as identity primary key,
  farm_name text not null check (char_length(btrim(farm_name)) between 1 and 12),
  time_seconds integer not null check (time_seconds between 1 and 2100),
  created_at timestamptz not null default now()
);

create index if not exists leaderboard_fastest_first
  on public.leaderboard (time_seconds asc, created_at asc);

alter table public.leaderboard enable row level security;

grant select, insert on public.leaderboard to anon, authenticated;
grant usage, select on sequence public.leaderboard_id_seq to anon, authenticated;

drop policy if exists "Everyone can read leaderboard" on public.leaderboard;
create policy "Everyone can read leaderboard"
  on public.leaderboard for select
  to anon, authenticated
  using (true);

drop policy if exists "Players can submit a farm result" on public.leaderboard;
create policy "Players can submit a farm result"
  on public.leaderboard for insert
  to anon, authenticated
  with check (
    char_length(btrim(farm_name)) between 1 and 12
    and time_seconds between 1 and 2100
    and lower(farm_name) !~ '(epstein|epstien|hitler|stalin|mussolini|pol[[:space:]]*pot|putin|poutine|fuck|shit|merde|putain|connard|connasse|salope|encule|nique)'
  );
