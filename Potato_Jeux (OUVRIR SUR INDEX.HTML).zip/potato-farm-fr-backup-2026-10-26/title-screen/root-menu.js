﻿(() => {
  const $ = (selector) => document.querySelector(selector);
  const backdrop = $('#modal-backdrop');
  const modal = $('#modal');
  const fade = $('#fade-curtain');
  const opening = $('#title-intro');
  requestAnimationFrame(() => opening.classList.add('show'));
  setTimeout(() => opening.classList.add('lift'), 1750);
  setTimeout(() => opening.classList.add('flash'), 2250);
  setTimeout(() => {
    opening.classList.add('exit');
    setTimeout(() => {
      opening.remove();
      $('#title-content').classList.add('intro-complete');
    }, 700);
  }, 2500);
  const storageGet = (key, fallback = null) => { try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; } };
  const storageSet = (key, value) => { try { localStorage.setItem(key, value); return true; } catch { return false; } };
  $('#leaderboard-view').classList.add('hidden');
  $('#title-content').classList.remove('hidden');
  backdrop.classList.add('hidden');
  const query = new URLSearchParams(location.search);
  const scoreKey = 'fermeAuxPatates.titleScores';
  let titleScores = [];
  try {
    const stored = JSON.parse(storageGet(scoreKey, '[]'));
    if (Array.isArray(stored)) titleScores = stored.filter(score => score && typeof score.name === 'string' && Number.isFinite(Number(score.time)) && Number(score.time) >= 0).map(score => ({name: score.name, time: Number(score.time)}));
  } catch {}
  if (query.get('unlock') === '1') storageSet('fermeAuxPatates.titleUnlocked', '1');
  const queryName = query.get('farmName');
  const queryTime = Number(query.get('time'));
  if (queryName && Number.isFinite(queryTime) && queryTime >= 0) {
    if (!titleScores.some(score => score.name === queryName && score.time === queryTime)) titleScores.push({ name: queryName, time: queryTime });
    titleScores.sort((a, b) => a.time - b.time);
    titleScores = titleScores.slice(0, 10);
    storageSet(scoreKey, JSON.stringify(titleScores));
  }
  if (query.toString()) { try { history.replaceState(null, '', location.pathname); } catch {} }
  const unlocked = query.get('unlock') === '1' || storageGet('fermeAuxPatates.titleUnlocked') === '1';
  if (unlocked) {
    $('#infinite').classList.remove('locked');
    $('#infinite').classList.add('green');
    $('#infinite').innerHTML = 'Infini';
  }
  const banned = ['epstein','epstien','hitler','stalin','mussolini','pol pot','poutine','putin','fuck','shit','merde','putain','connard','connasse','batard','bâtard','salope','encule','enculé','pedo','pédé'];
  const normalize = (value) => value.toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const isBadName = (value) => !value.trim() || banned.some((word) => normalize(value).includes(normalize(word)));
  const closeModal = () => { backdrop.classList.add('hidden'); modal.className = 'modal'; document.body.classList.remove('modal-open'); };
  const openModal = (kind, content, after) => { modal.className = `modal ${kind || ''}`; modal.innerHTML = content; backdrop.classList.remove('hidden'); document.body.classList.add('modal-open'); after?.(); };
  const showLocked = () => openModal('', `<h2 id="modal-title">⚠ MODE VERROUILLÉ ⚠</h2><p>Ce mode de jeu sera disponible lorsque vous aurez terminé l’histoire.</p><div class="modal-actions"><button class="cartoon red" id="ok">D’accord</button></div>`, () => { $('#ok').onclick = closeModal; });
  const showNameForm = () => openModal('name', `<h2 id="modal-title">Choisissez un nom de ferme</h2><p>Ce nom apparaîtra dans le classement. 12 caractères maximum.</p><input id="farm-name" maxlength="12" autocomplete="off" placeholder="Ma petite ferme"><p class="error hidden" id="name-error">Ce nom ne peut pas être utilisé. Choisissez-en un autre.</p><div class="modal-actions"><button class="cartoon red" id="cancel">Annuler</button><button class="cartoon green" id="continue">Continuer</button></div>`, () => {
    const input = $('#farm-name'); const error = $('#name-error'); const next = $('#continue');
    const validate = () => { const invalid = isBadName(input.value); input.classList.toggle('invalid', invalid && input.value.length > 0); error.classList.toggle('hidden', !invalid || !input.value); next.disabled = invalid; };
    input.addEventListener('input', validate); $('#cancel').onclick = closeModal; next.onclick = () => { validate(); if (isBadName(input.value)) return; fade.classList.remove('on'); void fade.offsetWidth; fade.classList.add('on'); setTimeout(() => { location.href = `story-intro/index.html?farmName=${encodeURIComponent(input.value.trim())}`; }, 330); }; input.focus(); validate();
  });
  $('#play').onclick = showNameForm;
  $('#infinite').onclick = unlocked ? () => { location.href = 'game.html?mode=infinite&unlock=1'; } : showLocked;
  $('#leave-leaderboard').onclick = () => { fade.classList.remove('on'); void fade.offsetWidth; fade.classList.add('on'); setTimeout(() => { $('#leaderboard-view').classList.add('hidden'); $('#title-content').classList.remove('hidden'); }, 330); };
  const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const drawScores = (scores) => { $('#leader-list').innerHTML = Array.from({length:10},(_,i)=>{const score=scores[i];const time=score?`${Math.floor(score.time/3600)} h ${String(Math.floor(score.time%3600/60)).padStart(2,'0')} min ${String(score.time%60).padStart(2,'0')} s`:'—';return `<li><span><b>#${i+1}</b> <span class="${score?'':'empty-rank'}">${score?escapeHtml(score.name):'— Ferme libre —'}</span></span><span>${time}</span></li>`;}).join(''); };
  const renderLeaderboard = async () => {
    const config = window.FERME_SUPABASE || {};
    if (!config.url || !config.anonKey) { $('#leader-status').textContent = titleScores.length ? 'Classement enregistré sur cet appareil.' : 'Aucune ferme classée pour le moment.'; drawScores(titleScores); return; }
    $('#leader-status').textContent = 'Chargement du classement partagé…'; drawScores(titleScores);
    try { const response=await fetch(`${config.url.replace(/\/$/,'')}/rest/v1/leaderboard?select=farm_name,time_seconds&order=time_seconds.asc,created_at.asc&limit=10`,{headers:{apikey:config.anonKey,Authorization:`Bearer ${config.anonKey}`}}); if(!response.ok) throw new Error(`HTTP ${response.status}`); const rows=await response.json(); const scores=rows.map(row=>({name:row.farm_name,time:Number(row.time_seconds)})); $('#leader-status').textContent=scores.length?`${scores.length} ferme${scores.length>1?'s':''} dans le classement partagé.`:'Aucune ferme classée pour le moment.'; drawScores(scores); }
    catch { $('#leader-status').textContent='Classement partagé indisponible. Classement local affiché.'; drawScores(titleScores); }
  };
  $('#leaderboard').onclick = () => { fade.classList.remove('on'); void fade.offsetWidth; fade.classList.add('on'); setTimeout(() => { $('#title-content').classList.add('hidden'); $('#leaderboard-view').classList.remove('hidden'); renderLeaderboard(); }, 330); };
  backdrop.addEventListener('click', (event) => { if (event.target === backdrop) closeModal(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && !backdrop.classList.contains('hidden')) closeModal(); });
})();


