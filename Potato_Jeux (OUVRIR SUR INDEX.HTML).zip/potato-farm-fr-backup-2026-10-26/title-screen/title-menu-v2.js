(() => {
  const $ = (selector) => document.querySelector(selector);
  const backdrop = $('#modal-backdrop');
  const modal = $('#modal');
  const fade = $('#fade-curtain');
  $('#leaderboard-view').classList.add('hidden');
  $('#title-content').classList.remove('hidden');
  backdrop.classList.add('hidden');
  const banned = ['epstein','epstien','hitler','stalin','mussolini','pol pot','poutine','putin','fuck','shit','merde','putain','connard','connasse','batard','bâtard','salope','encule','enculé','pedo','pédé'];
  const normalize = (value) => value.toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const isBadName = (value) => !value.trim() || banned.some((word) => normalize(value).includes(normalize(word)));
  const closeModal = () => { backdrop.classList.add('hidden'); modal.className = 'modal'; document.body.classList.remove('modal-open'); };
  const openModal = (kind, content, after) => { modal.className = `modal ${kind || ''}`; modal.innerHTML = content; backdrop.classList.remove('hidden'); document.body.classList.add('modal-open'); after?.(); };
  const showLocked = () => openModal('', `<h2 id="modal-title">⚠ MODE VERROUILLÉ ⚠</h2><p>Ce mode de jeu sera disponible lorsque vous aurez terminé l’histoire.</p><div class="modal-actions"><button class="cartoon red" id="ok">D’accord</button></div>`, () => { $('#ok').onclick = closeModal; });
  const showNameForm = () => openModal('name', `<h2 id="modal-title">Choisissez un nom de ferme</h2><p>Ce nom apparaîtra dans le classement. 12 caractères maximum.</p><input id="farm-name" maxlength="12" autocomplete="off" placeholder="Ma petite ferme"><p class="error hidden" id="name-error">Ce nom ne peut pas être utilisé. Choisissez-en un autre.</p><div class="modal-actions"><button class="cartoon red" id="cancel">Annuler</button><button class="cartoon green" id="continue">Continuer</button></div>`, () => {
    const input = $('#farm-name'); const error = $('#name-error'); const next = $('#continue');
    const validate = () => { const invalid = isBadName(input.value); input.classList.toggle('invalid', invalid && input.value.length > 0); error.classList.toggle('hidden', !invalid || !input.value); next.disabled = invalid; };
    input.addEventListener('input', validate); $('#cancel').onclick = closeModal; next.onclick = () => { validate(); if (isBadName(input.value)) return; localStorage.setItem('fermeAuxPatates.pendingName', input.value.trim()); fade.classList.remove('on'); void fade.offsetWidth; fade.classList.add('on'); setTimeout(() => { location.href = '../game.html?start=story'; }, 330); }; input.focus(); validate();
  });
  $('#play').onclick = showNameForm;
  $('#infinite').onclick = showLocked;
  $('#leave-leaderboard').onclick = () => { fade.classList.remove('on'); void fade.offsetWidth; fade.classList.add('on'); setTimeout(() => { $('#leaderboard-view').classList.add('hidden'); $('#title-content').classList.remove('hidden'); }, 330); };
  $('#leaderboard').onclick = () => { fade.classList.remove('on'); void fade.offsetWidth; fade.classList.add('on'); setTimeout(() => { $('#title-content').classList.add('hidden'); $('#leaderboard-view').classList.remove('hidden'); $('#leader-list').innerHTML = Array.from({length:10},(_,i)=>`<li><span><b>#${i+1}</b> <span class="empty-rank">— Ferme libre —</span></span><span>—</span></li>`).join(''); }, 330); };
  backdrop.addEventListener('click', (event) => { if (event.target === backdrop) closeModal(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && !backdrop.classList.contains('hidden')) closeModal(); });
})();
