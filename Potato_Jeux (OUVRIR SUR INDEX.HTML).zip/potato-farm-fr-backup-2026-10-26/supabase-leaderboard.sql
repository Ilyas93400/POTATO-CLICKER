-- Run once in the Supabase project's SQL Editor.
create table if not exists public.leaderboard (
  id uuid primary key default gen_random_uuid(),
  farm_name text not null check (char_length(btrim(farm_name)) between 1 and 12),
  time_seconds integer not null check (time_seconds >= 0),
  created_at timestamptz not null default now()
);

alter table public.leaderboard enable row level security;

grant select, insert on public.leaderboard to anon;

drop policy if exists "Anyone can view leaderboard" on public.leaderboard;
create policy "Anyone can view leaderboard"
on public.leaderboard
for select to anon
using (true);

drop policy if exists "Anyone can submit a score" on public.leaderboard;
create policy "Anyone can submit a score"
on public.leaderboard
for insert to anon
with check (
  char_length(btrim(farm_name)) between 1 and 12
  and time_seconds >= 0
);
