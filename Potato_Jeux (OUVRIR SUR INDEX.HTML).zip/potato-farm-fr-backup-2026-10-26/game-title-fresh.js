(() => {
  'use strict';
  const $ = (s) => document.querySelector(s);
  const screens = [...document.querySelectorAll('.screen')];
  const STORE = 'fermeAuxPatates.v1';
  const initial = () => ({money:0, day:1, seconds:300, clicks:0, farms:0, workers:0, luck:0, name:'', won:false, infinite:false, running:false, stage:'title', elapsed:0, goldenUsed:false, goldenLeft:0, goldenVisible:false});
  let state = initial();
  let leaders = [];
  let leaderStatus = 'Chargement du classement partag?';
  let tickHandle = null;
  let saveHandle = null;
  let toastTimer;
  const upgradeInfo = [
    {key:'clicks', icon:'???', name:'Clics renforc?s', base:50, growth:1.2, description:'La r?colte par clic est doubl?e.'},
    {key:'farms', icon:'??', name:'Nouvelles parcelles', base:500, growth:2.5, description:'Produisent des patates chaque seconde.'},
    {key:'workers', icon:'?????', name:'Ouvriers agricoles', base:5000, growth:1.5, description:'Des r?colteurs travaillent pour vous.'},
    {key:'luck', icon:'?', name:'Chance de patate dor?e', base:30000, growth:3, description:'Augmente la chance de trouver une patate dor?e.'}
  ];
  const number = (n) => Math.floor(n).toLocaleString('fr-FR');
  const price = (u) => Math.ceil(u.base * Math.pow(u.growth, state[u.key]));
  const farmPps = () => state.farms ? 5 * Math.pow(1.4, state.farms - 1) : 0;
  const workerPps = () => state.workers ? 30 * Math.pow(1.5, state.workers - 1) : 0;
  const pps = () => farmPps() + workerPps();
  const persist = () => { try { localStorage.setItem(STORE, JSON.stringify({state, leaders})); } catch {} };
  const switchTo = (id) => { screens.forEach(el => el.classList.toggle('active', el.id === id)); };
  const showToast = (message) => { const el=$('#toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),1600); };
  const transition = (callback, flash=false) => { const el=$('#fade-curtain'); el.classList.remove('fade','flash'); void el.offsetWidth; el.classList.add(flash?'flash':'fade'); setTimeout(callback, flash?360:330); };
  const openModal = (html, options={}) => { const modal=$('#modal'); modal.innerHTML=html; modal.className=`modal ${options.className||''}`; document.body.classList.add('modal-open'); $('#modal-backdrop').classList.remove('hidden'); options.after?.(modal); };
  const closeModal = () => { const backdrop=$('#modal-backdrop');backdrop.classList.add('closing');setTimeout(()=>{backdrop.classList.add('hidden');backdrop.classList.remove('closing');document.body.classList.remove('modal-open');},180); };
  const resumeStory = () => {
    switchTo('story');const env=$('#envelope'),paper=$('#news-paper'),phone=$('#phone-intro'),hint=$('.story-hint');
    env.classList.remove('hidden','open');paper.classList.add('hidden');paper.classList.remove('letter-peek','reading');phone.classList.add('hidden');hint.classList.remove('hidden');hint.textContent='Une lettre vous attend?';$('#story').classList.remove('paper-reading');
    if(state.stage==='letter-peek'){env.classList.add('open');env.classList.add('hidden');paper.classList.remove('hidden');paper.classList.add('letter-peek');hint.classList.add('hidden');}
    if(state.stage==='letter-read'){env.classList.add('hidden');paper.classList.remove('hidden');paper.classList.add('reading');hint.classList.add('hidden');$('#story').classList.add('paper-reading');}
    if(state.stage==='bank'){env.classList.add('hidden');hint.classList.add('hidden');phone.classList.remove('hidden');}
  };
  const render = () => {
    $('#money').textContent = `${number(state.money)} $`;
    $('#play').textContent=state.running||['envelope','letter-peek','letter-read','bank'].includes(state.stage)?'Reprendre':'Jouer';
    $('#pps').textContent = number(pps());
    const remaining=state.infinite?Infinity:Math.max(0,8-state.day);
    $('#day-count').textContent = state.infinite ? '8' : remaining;
    $('.day-calendar small').textContent=state.infinite?'sans limite':remaining===7?'semaine restante':'jours restants';
    $('#clock').textContent = `${Math.floor(state.seconds/60)}:${String(state.seconds%60).padStart(2,'0')}`;
    const weather=$('#weather'); weather.classList.toggle('evening',state.seconds<=180&&state.seconds>60); weather.classList.toggle('night',state.seconds<=60);
    $('#potato').classList.toggle('golden',state.goldenLeft>0);
    $('#gold-potato').classList.toggle('hidden',!state.goldenVisible);
    const list=$('#upgrade-list');
    list.innerHTML=upgradeInfo.map(u=>{const cost=price(u),count=state[u.key];return `<button class="upgrade" data-upgrade="${u.key}" ${state.money<cost?'disabled':''}><span class="up-count">${count}</span><span class="up-icon">${u.icon}</span><b>${u.name}<small>Niveau ${count} ? ${u.description}</small></b><span class="cost">${number(cost)} $</span></button>`}).join('');
    $('#lock').textContent=state.won?'':'??';
    $('#infinite').classList.toggle('green',state.won); $('#infinite').classList.toggle('muted',!state.won);
  };
  const clearTimers = () => { clearInterval(tickHandle); clearInterval(saveHandle); tickHandle=null; saveHandle=null; };
  const runGame = () => { clearTimers(); switchTo('game'); state.running=true; state.stage='game'; persist(); render();
    tickHandle=setInterval(()=>{
      state.money+=pps()*(state.goldenLeft>0?2:1);
      if(state.goldenLeft>0){state.goldenLeft--;if(state.goldenLeft===0){state.goldenVisible=false;showToast('La lueur dor?e s?est dissip?e.');}}
      if(!state.infinite && state.seconds>0){state.seconds--;state.elapsed++; if(state.seconds===0)nextDay();}
      if(state.luck>0&&!state.goldenUsed&&!state.infinite&&Math.random()<state.luck*0.005){state.goldenVisible=true;showToast('Une patate dor?e est apparue !');}
      render();persist();
    },1000);
    saveHandle=setInterval(persist,4000);
  };
  const startStory = () => {
    const saved=state.name, unlocked=state.won; state=initial();state.name=saved;state.won=unlocked;state.running=false;state.stage='envelope';state.elapsed=0;persist();
    switchTo('story');$('#envelope').classList.remove('open');$('#envelope').classList.remove('hidden');$('#news-paper').classList.add('hidden');$('#phone-intro').classList.add('hidden');$('.story-hint').classList.remove('hidden');
  };
  const nextDay = () => {
    if(state.goldenLeft){state.goldenLeft=0;state.goldenVisible=false;}
    state.goldenUsed=false;
    if(state.day>=7){state.running=false;clearTimers();persist(); transition(()=>{if(state.money>=1000000)showLicense();else showLoss();});return;}
    transition(()=>{state.day++;state.seconds=300;render();persist();showToast(`Jour ${state.day} : une nouvelle journ?e commence !`);});
  };
  const showLoss = () => { switchTo('ending');$('#ending').className='screen ending-screen lose active';$('#ending-content').innerHTML=`<h1>VOUS AVEZ PERDU</h1><p>Sans licence, votre ferme est saisie?</p><button class="cartoon red" id="restart">Recommencer</button>`;$('#restart').onclick=()=>transition(()=>{state=initial();persist();switchTo('title');render();},true); };
  const formatTime = (secs) => `${Math.floor(secs/3600)} h ${String(Math.floor(secs%3600/60)).padStart(2,'0')} min ${String(secs%60).padStart(2,'0')} s`;
  const showLicense = () => {switchTo('ending');$('#ending').className='screen ending-screen active';$('#ending-content').innerHTML=`<div class="license"><p>R?PUBLIQUE FRAN?AISE ? MINIST?RE DE L?AGRICULTURE</p><h2>LICENCE DE CULTURE</h2><p>La pr?sente autorise</p><strong>${escapeHtml(state.name)}</strong><p>? cultiver des pommes de terre en toute l?galit?.</p><p>Valable ? compter de ce jour ? Sceau officiel ?</p></div><button class="cartoon green" id="buy-license">Acheter la licence ? 1 000 000 $</button>`;$('#buy-license').onclick=()=>{state.money-=1000000;state.won=true;state.running=false;state.infinite=false;const entry={name:state.name,time:state.elapsed};persist();showWin();submitSharedScore(entry).then(()=>{const status=$('#score-sync-status');if(status)status.textContent='Votre ferme a ?t? publi?e dans le classement partag?.';}).catch(error=>{const status=$('#score-sync-status');if(status)status.textContent='R?sultat non envoy?. V?rifiez la configuration du classement partag?.';console.error('Envoi du r?sultat Supabase impossible.',error);});};};
  const showWin = () => {switchTo('ending');$('#ending').className='screen ending-screen win active';$('#ending-content').innerHTML=`<h1>VOUS AVEZ GAGN? !</h1><p>Licence obtenue en <strong>${formatTime(state.elapsed)}</strong></p><p id="score-sync-status">Publication du r?sultat?</p><button class="cartoon green" id="to-title">Retour au menu</button>`;$('#to-title').onclick=()=>transition(()=>{switchTo('title');render();},true);};
  const renderLeaders = () => {const ol=$('#leader-list');ol.innerHTML='';$('#leader-status').textContent=leaderStatus;for(let i=0;i<10;i++){const row=leaders[i];const li=document.createElement('li');li.innerHTML=row?`<span class="rank-name"><b>#${i+1}</b><span>${escapeHtml(row.name)}</span></span><span>${formatTime(row.time)}</span>`:`<span class="rank-name"><b>#${i+1}</b><span>? Ferme libre ?</span></span><span>?</span>`;ol.append(li);}};
  const supabaseConfig = () => window.FERME_SUPABASE || {};
  const supabaseReady = () => Boolean(supabaseConfig().url && supabaseConfig().anonKey);
  const loadSharedLeaders = async () => {
    if(!supabaseReady()){leaders=[];leaderStatus='Ajoutez l?URL du projet et la cl? publique Supabase dans supabase-config.js.';renderLeaders();return;}
    const config=supabaseConfig(),base=config.url.replace(/\/$/,''),headers={apikey:config.anonKey,Authorization:`Bearer ${config.anonKey}`};
    leaderStatus='Connexion au classement partag?';renderLeaders();
    try{const response=await fetch(`${base}/rest/v1/leaderboard?select=farm_name,time_seconds&order=time_seconds.asc,created_at.asc&limit=10`,{headers});if(!response.ok)throw new Error(`HTTP ${response.status}`);const rows=await response.json();leaders=rows.map(row=>({name:row.farm_name,time:Number(row.time_seconds)}));leaderStatus=leaders.length?`${leaders.length} ferme${leaders.length>1?'s':''} class?e${leaders.length>1?'s':''} ? classement partag?`:'Aucune ferme class?e pour le moment.';persist();}catch(error){leaders=[];leaderStatus='Connexion impossible au classement partag?. V?rifiez la configuration Supabase.';console.error('Chargement du classement Supabase impossible.',error);}renderLeaders();
  };
  const submitSharedScore = async (entry) => {
    if(!supabaseReady())throw new Error('La configuration Supabase est manquante.');
    const config=supabaseConfig(),base=config.url.replace(/\/$/,''),response=await fetch(`${base}/rest/v1/leaderboard`,{method:'POST',headers:{apikey:config.anonKey,Authorization:`Bearer ${config.anonKey}`,'Content-Type':'application/json',Prefer:'return=minimal'},body:JSON.stringify({farm_name:entry.name,time_seconds:entry.time})});
    if(!response.ok)throw new Error(`HTTP ${response.status}`);
    await loadSharedLeaders();
  };
  const escapeHtml = (s) => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const banned = ['epstein','epstien','hitler','stalin','mussolini','pol pot','gengis khan','genghis khan','idi amin','mao tse','poutine','putin','fuck','shit','merde','putain','connard','connasse','b?tard','batard','salope','encul?','encule','nique','foutre','bite','couille','p?d?','pedo'];
  const invalidName = (name) => {const normalized=name.toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g,'');return !name.trim()||banned.some(word=>normalized.includes(word.normalize('NFD').replace(/[\u0300-\u036f]/g,'')));};
  const nameModal = () => openModal(`<h2>Choisissez un nom de ferme</h2><p>Votre nom appara?tra au classement. 12 caract?res maximum.</p><input id="farm-name" maxlength="12" autocomplete="off" placeholder="Ma petite ferme"><p class="name-error hidden" id="name-error">Ce nom ne peut pas ?tre utilis?. Choisissez-en un autre.</p><div class="actions"><button class="cartoon red" id="cancel-name">Annuler</button><button class="cartoon green" id="continue-name">Continuer</button></div>`,{className:'name-modal',after:(m)=>{const input=m.querySelector('#farm-name'),err=m.querySelector('#name-error');const validate=()=>{const bad=invalidName(input.value);input.classList.toggle('invalid',bad&&input.value.length>0);err.classList.toggle('hidden',!bad||!input.value);return !bad;};input.oninput=validate;input.focus();m.querySelector('#cancel-name').onclick=closeModal;m.querySelector('#continue-name').onclick=()=>{if(!validate())return;state.name=input.value.trim();persist();closeModal();transition(()=>{startStory();});};}});
  const warningModal = (title,text,confirm,action) => openModal(`<h2>${title}</h2><p>${text}</p><div class="actions"><button class="cartoon red" id="modal-cancel">Annuler</button><button class="cartoon red" id="modal-confirm">${confirm}</button></div>`,{after:(m)=>{m.querySelector('#modal-cancel').onclick=closeModal;m.querySelector('#modal-confirm').onclick=()=>{closeModal();action();};}});
  $('#play').onclick=()=>{if(state.running){transition(()=>runGame(),true);return;}if(['envelope','letter-peek','letter-read','bank'].includes(state.stage)){transition(resumeStory);return;}nameModal();};
  $('#infinite').onclick=()=>{if(!state.won){openModal(`<h2>? MODE VERROUILL? ?</h2><p>Ce mode sera disponible lorsque vous aurez termin? l?histoire.</p><div class="actions"><button class="cartoon red" id="modal-ok">D?accord</button></div>`,{className:'locked-modal',after:m=>m.querySelector('#modal-ok').onclick=closeModal});return;}state.infinite=true;state.day=1;state.seconds=300;transition(()=>runGame(),true);};
  $('#leaderboard').onclick=()=>transition(()=>{switchTo('leaderboard-screen');renderLeaders();loadSharedLeaders();},true);
  $('#leave-leaderboard').onclick=()=>transition(()=>switchTo('title'),true);
  $('#envelope').onclick=()=>{const env=$('#envelope');if(env.classList.contains('open'))return;env.classList.add('open');state.stage='letter-peek';persist();$('.story-hint').textContent='Touchez la lettre pour la lire';setTimeout(()=>{$('.story-hint').classList.add('hidden');$('#news-paper').classList.remove('hidden');$('#news-paper').classList.add('letter-peek');},700);};
  $('#envelope').onkeydown=(e)=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('#envelope').click();}};
  $('#news-paper').onclick=(e)=>{if(e.target.closest('button')||$('#news-paper').classList.contains('reading'))return;$('#news-paper').classList.remove('letter-peek');$('#news-paper').classList.add('reading');$('#story').classList.add('paper-reading');state.stage='letter-read';persist();};
  $('#paper-continue').onclick=()=>{$('#news-paper').classList.add('hidden');$('#envelope').classList.add('hidden');$('#phone-intro').classList.remove('hidden');state.stage='bank';persist();};
  $('#start-farming').onclick=()=>transition(()=>runGame());
  $('#potato').onclick=(event)=>{const gain=Math.pow(2,state.clicks)*(state.goldenLeft>0?2:1);state.money+=gain;const box=$('#floaters'),r=event.currentTarget.getBoundingClientRect(),f=document.createElement('span');f.className='floater';f.textContent=`+${number(gain)} patate${gain>1?'s':''}`;f.style.left=`${Math.max(8,Math.min(75,((event.clientX-r.left)/r.width)*100))}%`;f.style.top=`${Math.max(15,Math.min(74,((event.clientY-r.top)/r.height)*100))}%`;box.append(f);setTimeout(()=>f.remove(),900);if(state.goldenVisible){state.goldenVisible=false;state.goldenUsed=true;state.goldenLeft=10;showToast('R?colte dor?e : gains doubl?s pendant 10 secondes !');}render();persist();};
  $('#gold-potato').onclick=(e)=>{e.stopPropagation();$('#potato').click();};
  $('#upgrade-list').onclick=(e)=>{const btn=e.target.closest('[data-upgrade]');if(!btn)return;const u=upgradeInfo.find(x=>x.key===btn.dataset.upgrade),cost=price(u);if(state.money<cost)return;state.money-=cost;state[u.key]++;render();persist();showToast(`${u.name} achet? !`);};
  $('#end-day').onclick=()=>openModal(`<h2>? AVERTISSEMENT ?</h2><p>Voulez-vous vraiment terminer cette journ?e en avance ?</p><div class="actions"><button class="cartoon red" id="modal-cancel">Annuler</button><button class="cartoon red" id="modal-confirm">Oui, je suis s?r</button></div>`,{className:'warning-modal',after:m=>{m.querySelector('#modal-cancel').onclick=closeModal;m.querySelector('#modal-confirm').onclick=()=>{closeModal();state.seconds=0;nextDay();};}});
  let loaded=false;try{const raw=localStorage.getItem(STORE);if(raw){const data=JSON.parse(raw);if(data.state)state={...initial(),...data.state};loaded=true;}}catch{}
  render();
  // A direct menu link skips the intro; normal launches play it first.
  if(new URLSearchParams(location.search).get('screen')==='title') switchTo('title');
  else {switchTo('intro');setTimeout(()=>$('.intro-title').classList.add('lift'),1450);setTimeout(()=>transition(()=>switchTo('title'),true),2200);}
  window.addEventListener('beforeunload',persist);
})();
