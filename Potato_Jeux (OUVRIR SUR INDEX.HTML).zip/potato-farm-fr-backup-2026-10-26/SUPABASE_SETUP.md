# Connect the shared leaderboard

The game is ready to use Supabase for shared scores. To activate it:

1. Create a Supabase project at [supabase.com](https://supabase.com) if you do not already have one.
2. In the Supabase SQL Editor, run the contents of `supabase-schema.sql`.
3. In Project Settings → API, copy the **Project URL** and the **anon/public key**.
4. Put those two values in `supabase-config.js` as `url` and `anonKey`.
5. Publish this folder on your website host. Every player must load the same published copy.

The browser uses the public anon key with row-level security policies from the SQL file. Never put a `service_role` key in the website.
